% =========================================================================
% Master Script: PTA6043 Slide Potentiometer Characterization
% Models: PTA6043-2015DPA103 (Log), PTA6043-2015DPB103 (Linear)
% =========================================================================

clc; clear; close all;
if ~isempty(serialportfind)
    delete(serialportfind);
end

% --- 1. เลือกรุ่น Slide Potentiometer ที่ต้องการทดลอง ---
fprintf('=======================================================\n');
fprintf('  โปรดเลือกเบอร์ PTA6043 Slide Potentiometer ที่กำลังทดสอบ:\n');
fprintf('=======================================================\n');
fprintf(' 1: PTA6043-2015DPA103  (Logarithmic / Audio Taper)\n');
fprintf(' 2: PTA6043-2015DPB103  (Linear Taper)\n');
choice = input('พิมพ์หมายเลข (1-2) แล้วกด Enter: ');

switch choice
    case 1
        part_name = 'PTA6043-2015DPA103';
        type_label = 'Logarithmic (Type A)';
    case 2
        part_name = 'PTA6043-2015DPB103';
        type_label = 'Linear (Type B)';
    otherwise
        error('ตัวเลือกไม่ถูกต้อง กรุณารันสคริปต์ใหม่อีกครั้ง');
end

fprintf('\n=======================================================\n');
fprintf(' สคริปต์ Characterization %s 3 รอบ\n', part_name);
fprintf('=======================================================\n\n');

runs_analog = cell(1, 3);
runs_schmitt = cell(1, 3);

% --- 2. วนลูปบันทึกข้อมูล 3 รอบ ---
for r = 1:3
    fprintf('-------------------------------------------------------\n');
    fprintf(' >>> [รอบที่ %d / 3] <<<\n', r);
    fprintf(' 1. เลื่อนก้านสไลด์ไปที่จุดเริ่มต้น (0 mm / ดันลงล่างสุด)\n');
    fprintf(' 2. กดปุ่ม [RUN] ใน Simulink\n');
    fprintf(' 3. ค่อยๆ เลื่อนสไลด์ไปจนสุด (60 mm / ดันขึ้นบนสุด) ช้าๆ 5-10 วินาที\n');
    fprintf('    จากนั้นเลื่อนกลับมาที่ 0 mm\n');
    fprintf(' 4. กดปุ่ม [STOP] ใน Simulink\n');
    fprintf('-------------------------------------------------------\n');
    
    input('>>> เมื่อรันและกด STOP ใน Simulink เสร็จแล้ว กด Enter ในนี้เพื่อเซฟค่า... ', 's');
    
    % --- ดึงข้อมูลจาก Simulink Workspace ---
    % 1. ดึงค่า Analog ADC
    tempA = [];
    try
        tempA = out.adc_data;
    catch
        try
            tempA = out.out_adc_data;
        catch
        end
    end
    
    % 2. ดึงค่า Schmitt Trigger
    tempS = [];
    try
        tempS = out.out_schmitt;
    catch
        try
            tempS = out.schmitt;
        catch
        end
    end
    
    % แปลงรูปแบบข้อมูล (รองรับทั้ง Array และ Timeseries)
    if isstruct(tempA) || isa(tempA, 'timeseries')
        runs_analog{r} = tempA.Data;
    else
        runs_analog{r} = tempA;
    end
    
    if isstruct(tempS) || isa(tempS, 'timeseries')
        runs_schmitt{r} = tempS.Data;
    else
        runs_schmitt{r} = tempS;
    end
    
    if ~isempty(runs_analog{r})
        fprintf('>>> บันทึกข้อมูลรอบที่ %d สำเร็จ! (ได้ข้อมูล Analog %d จุด)\n\n', r, length(runs_analog{r}));
    else
        warning('รอบที่ %d: ดึงข้อมูลไม่สำเร็จ โปรดตรวจสอบว่าได้กด RUN และ STOP ใน Simulink แล้วหรือยัง', r);
    end
end

% --- 3. พล็อตกราฟสรุปผลและเซฟรูป ---
fig = figure('Name', sprintf('Characterization %s', part_name), 'Color', 'w', 'Position', [100 100 800 650]);

% กราฟที่ 1: สัญญาณ Analog Voltage
subplot(2,1,1);
hold on;
for r = 1:3
    if ~isempty(runs_analog{r})
        voltage = double(runs_analog{r}) * (3.3 / 4095); % สเกล ADC 12-bit เป็น 0 - 3.3V
        plot(voltage, 'LineWidth', 1.5, 'DisplayName', sprintf('Run %d', r));
    end
end
grid on;
title(sprintf('Analog Output Voltage: %s (%s)', part_name, type_label), 'FontSize', 12);
xlabel('Sample Points');
ylabel('Voltage (V)');
ylim([0 3.6]);
legend('Location', 'best');

% กราฟที่ 2: สัญญาณ Digital จาก Schmitt Trigger (Relay)
subplot(2,1,2);
hold on;
for r = 1:3
    if ~isempty(runs_schmitt{r})
        sch_val = double(runs_schmitt{r});
        plot(sch_val, 'LineWidth', 1.5, 'DisplayName', sprintf('Run %d', r));
    end
end
grid on;
title(sprintf('Schmitt Trigger Output (Relay): %s', part_name), 'FontSize', 12);
xlabel('Sample Points');
ylabel('Logic Output (0 / 1)');
ylim([-0.2 1.2]);
legend('Location', 'best');

% บันทึกไฟล์รูปภาพและ PDF
saveas(fig, sprintf('%s_schmitt_avg.png', part_name));
saveas(fig, sprintf('%s_schmitt_avg.pdf', part_name));
fprintf('\n=======================================================\n');
fprintf(' บันทึกรูปกราฟเรียบร้อย: %s_schmitt_avg.png และ .pdf\n', part_name);
fprintf('=======================================================\n');