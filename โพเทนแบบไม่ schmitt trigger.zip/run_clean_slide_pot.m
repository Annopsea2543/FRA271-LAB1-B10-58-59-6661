% =========================================================================
% Master Script: PTA6043 Slide Potentiometer (0 - 60 mm)
% (Individual 3-Subplots + Combined Average Figure)
% =========================================================================

clc; clear; close all;
delete(serialportfind);

fprintf('===========================================================\n');
fprintf('  สคริปต์ Characterization PTA6043 (Slide Pot 60mm) 3 รอบ\n');
fprintf('===========================================================\n\n');

runs = cell(1, 3);

% 1. วนลูปบันทึกข้อมูล 3 รอบ
for r = 1:3
    fprintf('-----------------------------------------------------------\n');
    fprintf('  >>> [รอบที่ %d / 3] <<<\n', r);
    fprintf('  1. เลื่อนก้านสไลด์ไปที่จุดเริ่มต้น (0 mm / ล่างสุด)\n');
    fprintf('  2. กดปุ่ม [RUN] ใน Simulink\n');
    fprintf('  3. ค่อยๆ เลื่อนสไลด์ไปจนสุด (60 mm / บนสุด) ช้าๆ 5-10 วินาที\n');
    fprintf('  4. กดปุ่ม [STOP] ใน Simulink\n');
    fprintf('-----------------------------------------------------------\n');
    
    input('--> เมื่อทำครบขั้นตอน 1-4 แล้ว ให้กด [ENTER] ในนี้เพื่อบันทึกรอบนี้...', 's');
    
    % ระบบค้นหาข้อมูลอัตโนมัติ
    raw_data = [];
    if evalin('base', 'exist(''adc_data'', ''var'')')
        raw_data = evalin('base', 'adc_data');
    elseif evalin('base', 'exist(''out'', ''var'')')
        out_struct = evalin('base', 'out');
        try, raw_data = out_struct.adc_data; catch
            try, raw_data = out_struct.simout; catch, end
        end
    end
    
    if isempty(raw_data)
        error('ไม่พบข้อมูล! กรุณาตรวจสอบว่ากด RUN และ STOP ใน Simulink หรือยัง');
    end
    
    if isa(raw_data, 'timeseries'), raw_data = raw_data.Data; end
    runs{r} = double(raw_data(:));
    fprintf('  [บันทึกสำเร็จ] รอบที่ %d เก็บข้อมูลได้ %d จุด\n\n', r, length(runs{r}));
end

% 2. ประมวลผลสเกลระยะทาง 0 - 60 mm
v_ref    = 3.3;
adc_res  = 4095; % 12-bit ADC
N_points = 1000;
mm_grid  = linspace(0, 60, N_points); % ระยะสไลด์จริง 0 - 60 mm

v_interp = zeros(3, N_points);
for r = 1:3
    v_raw = (runs{r} / adc_res) * v_ref;
    v_interp(r, :) = interp1(linspace(0, 60, length(v_raw)), v_raw, mm_grid, 'linear');
end
v_avg = mean(v_interp, 1);

% =========================================================================
% รูปที่ 1: กราฟแยก 3 รอบ (Individual Subplots)
% =========================================================================
figure('Name', 'PTA6043 - Individual Continuous Runs', 'Color', [1 1 1]);
colors = {[0.2 0.6 0.8], [0.2 0.8 0.4], [0.8 0.4 0.2]};
for r = 1:3
    subplot(3, 1, r);
    plot(mm_grid, v_interp(r, :), 'LineWidth', 1.5, 'Color', colors{r});
    grid on;
    title(sprintf('Run %d (Slide 0 - 60 mm)', r));
    ylabel('Voltage (V)');
    ylim([-0.2 3.6]);
    xlim([0 60]);
    xticks(0:10:60);
    if r == 3, xlabel('Slide Distance (mm)'); end
end

% =========================================================================
% รูปที่ 2: กราฟรวม 3 รอบ + ค่าเฉลี่ย (Combined Runs & Average)
% =========================================================================
figure('Name', 'PTA6043 - Combined 3 Runs & Average Curve', 'Color', [1 1 1]);
plot(mm_grid, v_interp(1,:), '--', 'LineWidth', 1.2, 'Color', [0.7 0.7 0.7], 'DisplayName', 'Run 1'); hold on;
plot(mm_grid, v_interp(2,:), '--', 'LineWidth', 1.2, 'Color', [0.5 0.5 0.5], 'DisplayName', 'Run 2');
plot(mm_grid, v_interp(3,:), '--', 'LineWidth', 1.3, 'Color', [0.3 0.3 0.3], 'DisplayName', 'Run 3');
plot(mm_grid, v_avg,         '-',  'LineWidth', 2.5, 'Color', [0.85 0.325 0.098], 'DisplayName', 'Average');

grid on;
title('PTA6043 Slide Potentiometer Characterization: 3 Continuous Runs & Average');
xlabel('Slide Distance (mm)');
ylabel('Voltage (V)');
xlim([-2 62]); 
ylim([-0.2 3.6]);
xticks(0:10:60);
legend('Location', 'northwest');

fprintf('===========================================================\n');
fprintf('  ประมวลผลสำเร็จ! แสดงผลทั้งกราฟแยก 3 รูป และกราฟรวมเรียบร้อยแล้ว\n');
fprintf('===========================================================\n');