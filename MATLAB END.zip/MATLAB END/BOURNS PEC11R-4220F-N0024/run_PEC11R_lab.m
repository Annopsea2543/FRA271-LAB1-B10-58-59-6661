% =========================================================================
% MATLAB Script: เก็บผล BOURNS PEC11R (24 PPR) + บันทึก .fig, .png, .pdf
% =========================================================================
clear; clc; close all;

PPR = 24; 
counts_per_rev = [PPR*1, PPR*2, PPR*4]; 

modes = {'X1', 'X2', 'X4'};
pos_vars = {'pos_x1', 'pos_x2', 'pos_x4'};
vel_vars = {'vel_x1', 'vel_x2', 'vel_x4'};

data_store = cell(3, 3); 

fprintf('=== เริ่มกระบวนการเก็บผล BOURNS PEC11R (24 PPR) ===\n');

for m = 1:3
    mode_name = modes{m};
    p_name = pos_vars{m};
    v_name = vel_vars{m};
    
    fprintf('\n---------------------------------------------------------\n');
    fprintf('  >>> เสียบสายสัญญาณพอร์ตโหมด %s บนบอร์ด STM32 <<<\n', mode_name);
    fprintf('---------------------------------------------------------\n');
    
    for trial = 1:3
        clear functions; 
        
        fprintf('[โหมด %s - รอบที่ %d/3] กด Run ใน Simulink -> หมุน PEC11R ให้ครบ 1 รอบ -> หมุนกลับ\n', mode_name, trial);
        input('เมื่อ Simulation สิ้นสุด ให้คลิกที่นี่แล้วกด Enter...');
        
        try
            pos_ts = evalin('base', p_name);
            vel_ts = evalin('base', v_name);
        catch
            out = evalin('base', 'out');
            pos_ts = out.(p_name);
            vel_ts = out.(v_name);
        end
        
        data_store{m, trial}.t   = pos_ts.Time;
        data_store{m, trial}.pos = pos_ts.Data - pos_ts.Data(1);
        data_store{m, trial}.vel = vel_ts.Data;
        
        fprintf('-> บันทึกผลโหมด %s รอบที่ %d สำเร็จ!\n', mode_name, trial);
    end
end

%% 1. บันทึกกราฟแยกโหมด (.fig, .png, .pdf)
for m = 1:3
    mode_name = modes{m};
    fig_ind = figure('Name', ['PEC11R - Mode ' mode_name], 'Color', [1 1 1], 'Position', [100 100 900 600]);
    
    % Position Subplot
    subplot(2,1,1); hold on; grid on;
    for t = 1:3
        plot(data_store{m, t}.t, data_store{m, t}.pos, 'LineWidth', 1.2, ...
            'DisplayName', sprintf('Trial %d', t));
    end
    title(sprintf('BOURNS PEC11R (24 PPR) - โหมด %s: ตำแหน่งเชิงมุม (Position)', mode_name));
    xlabel('Time (s)'); ylabel('Position (rad)');
    legend('Location', 'best');
    
    % Velocity Subplot
    subplot(2,1,2); hold on; grid on;
    for t = 1:3
        plot(data_store{m, t}.t, data_store{m, t}.vel, 'LineWidth', 1.2, ...
            'DisplayName', sprintf('Trial %d', t));
    end
    title(sprintf('BOURNS PEC11R (24 PPR) - โหมด %s: ความเร็วเชิงมุม (Velocity)', mode_name));
    xlabel('Time (s)'); ylabel('Velocity (rad/s)');
    ylim([-100 100]); 
    legend('Location', 'best');
    
    % คำสั่งส่งออกไฟล์ 3 ฟอร์แมต
    filename_ind = ['PEC11R_Individual_' mode_name];
    savefig(fig_ind, [filename_ind '.fig']);                                 % ไฟล์ .fig
    exportgraphics(fig_ind, [filename_ind '.png'], 'Resolution', 300);       % ไฟล์ .png (300 DPI)
    exportgraphics(fig_ind, [filename_ind '.pdf'], 'ContentType', 'vector'); % ไฟล์ .pdf
end

%% 2. บันทึกกราฟรวมเปรียบเทียบ X1 vs X2 vs X4 (.fig, .png, .pdf)
fig_comb = figure('Name', 'PEC11R - Combined Comparison', 'Color', [1 1 1], 'Position', [150 150 900 600]);

% Combined Position
subplot(2,1,1); hold on; grid on;
plot(data_store{1,1}.t, data_store{1,1}.pos, 'r-',  'LineWidth', 1.2, 'DisplayName', 'PEC11R X1 (24 PPR)');
plot(data_store{2,1}.t, data_store{2,1}.pos, 'g--', 'LineWidth', 1.2, 'DisplayName', 'PEC11R X2 (48 PPR)');
plot(data_store{3,1}.t, data_store{3,1}.pos, 'b:',  'LineWidth', 1.5, 'DisplayName', 'PEC11R X4 (96 PPR)');
title('เปรียบเทียบตำแหน่งเชิงมุม BOURNS PEC11R (X1 vs X2 vs X4)');
xlabel('Time (s)'); ylabel('Position (rad)');
legend('Location', 'best');

% Combined Velocity
subplot(2,1,2); hold on; grid on;
plot(data_store{1,1}.t, data_store{1,1}.vel, 'r-',  'LineWidth', 1.2, 'DisplayName', 'PEC11R X1 (24 PPR)');
plot(data_store{2,1}.t, data_store{2,1}.vel, 'g--', 'LineWidth', 1.2, 'DisplayName', 'PEC11R X2 (48 PPR)');
plot(data_store{3,1}.t, data_store{3,1}.vel, 'b:',  'LineWidth', 1.5, 'DisplayName', 'PEC11R X4 (96 PPR)');
title('เปรียบเทียบความเร็วเชิงมุม BOURNS PEC11R (X1 vs X2 vs X4)');
xlabel('Time (s)'); ylabel('Velocity (rad/s)');
ylim([-100 100]);
legend('Location', 'best');

% คำสั่งส่งออกไฟล์ 3 ฟอร์แมตสำหรับกราฟรวม
filename_comb = 'PEC11R_Combined_Comparison';
savefig(fig_comb, [filename_comb '.fig']);
exportgraphics(fig_comb, [filename_comb '.png'], 'Resolution', 300);
exportgraphics(fig_comb, [filename_comb '.pdf'], 'ContentType', 'vector');

save('PEC11R_All_Data.mat', 'data_store');
fprintf('\n=== บันทึกไฟล์ .fig, .png และ .pdf ครบถ้วนเรียบร้อยแล้ว ===\n');