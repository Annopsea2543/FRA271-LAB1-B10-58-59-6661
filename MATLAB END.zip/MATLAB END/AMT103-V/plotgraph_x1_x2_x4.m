% =========================================================================
% โค้ดเปรียบเทียบสัญญาณ X1, X2, X4 ในกราฟเดียวกัน
% =========================================================================
trial_to_compare = 1; % เลือก Trial ที่ต้องการนำมาทำกราฟเปรียบเทียบ (เช่น Trial 1)

baseFolder = 'Encoder_Results';
compareFolder = fullfile(baseFolder, 'Comparison_X1_X2_X4', sprintf('Trial_%d', trial_to_compare));
if ~exist(compareFolder, 'dir'), mkdir(compareFolder); end

% โหลดข้อมูลจาก .mat
matPath = fullfile(baseFolder, sprintf('Trial_%d', trial_to_compare), 'RawData.mat');
if ~exist(matPath, 'file')
    error('ไม่พบไฟล์ RawData.mat กรุณารันโค้ดส่วนแรกก่อน');
end
load(matPath);

% 1. กราฟเปรียบเทียบ Relative Position (Pulses)
f_comp_rel = figure('Name', 'Compare_Relative_Position', 'Visible', 'off');
plot(out.out_RelPos_X1.Time, out.out_RelPos_X1.Data, 'b', 'LineWidth', 1.2); hold on;
plot(out.out_RelPos_X2.Time, out.out_RelPos_X2.Data, 'g', 'LineWidth', 1.2);
plot(out.out_RelPos_X4.Time, out.out_RelPos_X4.Data, 'r', 'LineWidth', 1.2);
title(sprintf('Relative Position Comparison - X1 vs X2 vs X4 (Trial %d)', trial_to_compare));
xlabel('Time (s)'); ylabel('Relative Position (Pulses)');
legend('Mode X1', 'Mode X2', 'Mode X4', 'Location', 'best'); grid on;

% 2. กราฟเปรียบเทียบ Angular Position (Radians)
f_comp_ang = figure('Name', 'Compare_Angular_Position', 'Visible', 'off');
plot(out.out_AngPos_X1.Time, out.out_AngPos_X1.Data, 'b--', 'LineWidth', 1.2); hold on;
plot(out.out_AngPos_X2.Time, out.out_AngPos_X2.Data, 'g-.', 'LineWidth', 1.2);
plot(out.out_AngPos_X4.Time, out.out_AngPos_X4.Data, 'r', 'LineWidth', 1.2);
title(sprintf('Angular Position Comparison - X1 vs X2 vs X4 (Trial %d)', trial_to_compare));
xlabel('Time (s)'); ylabel('Angular Position (rad)');
legend('Mode X1', 'Mode X2', 'Mode X4', 'Location', 'best'); grid on;

% 3. กราฟเปรียบเทียบ Angular Velocity (rad/s)
f_comp_vel = figure('Name', 'Compare_Angular_Velocity', 'Visible', 'off');
plot(out.out_AngVel_X1.Time, out.out_AngVel_X1.Data, 'b', 'LineWidth', 1.0); hold on;
plot(out.out_AngVel_X2.Time, out.out_AngVel_X2.Data, 'g', 'LineWidth', 1.0);
plot(out.out_AngVel_X4.Time, out.out_AngVel_X4.Data, 'r', 'LineWidth', 1.0);
title(sprintf('Angular Velocity Comparison - X1 vs X2 vs X4 (Trial %d)', trial_to_compare));
xlabel('Time (s)'); ylabel('Velocity (rad/s)');
legend('Mode X1', 'Mode X2', 'Mode X4', 'Location', 'best'); grid on;

% บันทึกกราฟเปรียบเทียบ
saveFigureFiles(f_comp_rel, fullfile(compareFolder, 'Compare_Relative_Position'));
saveFigureFiles(f_comp_ang, fullfile(compareFolder, 'Compare_Angular_Position'));
saveFigureFiles(f_comp_vel, fullfile(compareFolder, 'Compare_Angular_Velocity'));

close([f_comp_rel, f_comp_ang, f_comp_vel]);
fprintf('สร้างกราฟเปรียบเทียบ X1, X2, X4 สำหรับ Trial %d เรียบร้อยแล้ว!\n', trial_to_compare);

function saveFigureFiles(figHandle, basePath)
    saveas(figHandle, [basePath '.fig']);
    saveas(figHandle, [basePath '.png']);
    exportgraphics(figHandle, [basePath '.pdf'], 'ContentType', 'vector');
end