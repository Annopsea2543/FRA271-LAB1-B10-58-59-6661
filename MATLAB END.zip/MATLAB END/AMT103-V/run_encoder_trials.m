% =========================================================================
% โค้ดบันทึกข้อมูลและสร้างกราฟแยกตามโหมด (X1, X2, X4) ประจำ Trial
% =========================================================================
trial = 3; % <--- เปลี่ยนเป็น 1, 2 หรือ 3 ก่อนรันโค้ดทุกครั้ง

baseFolder = 'Encoder_Results';
modes = {'X1', 'X2', 'X4'};

% 1. บันทึกไฟล์ข้อมูลดิบประจำ Trial
trialFolder = fullfile(baseFolder, sprintf('Trial_%d', trial));
if ~exist(trialFolder, 'dir'), mkdir(trialFolder); end
save(fullfile(trialFolder, 'RawData.mat'), 'out');

% 2. วนลูปสร้างกราฟและเซฟไฟล์แยกแต่ละโหมด (X1, X2, X4)
for i = 1:length(modes)
    m = modes{i};
    
    % กำหนด Path โฟลเดอร์แยก X1, X2, X4
    savePath = fullfile(baseFolder, m, sprintf('Trial_%d', trial));
    if ~exist(savePath, 'dir'), mkdir(savePath); end
    
    % ดึงข้อมูลจากโครงสร้าง out
    relPos = out.(['out_RelPos_' m]);
    angPos = out.(['out_AngPos_' m]);
    angVel = out.(['out_AngVel_' m]);
    
    % --- กราฟที่ 1: Position (Relative Position & Angular Position) ---
    f1 = figure('Name', ['Position_' m], 'Visible', 'off');
    subplot(2,1,1);
    plot(relPos.Time, relPos.Data, 'b', 'LineWidth', 1.2);
    title(sprintf('Relative Position (%s - Trial %d)', m, trial));
    xlabel('Time (s)'); ylabel('Pulses (Counts)'); grid on;
    
    subplot(2,1,2);
    plot(angPos.Time, angPos.Data, 'r', 'LineWidth', 1.2);
    title(sprintf('Angular Position (%s - Trial %d)', m, trial));
    xlabel('Time (s)'); ylabel('Angle (rad)'); grid on;
    
    % --- กราฟที่ 2: Angular Velocity ---
    f2 = figure('Name', ['Velocity_' m], 'Visible', 'off');
    plot(angVel.Time, angVel.Data, 'k', 'LineWidth', 1.2);
    title(sprintf('Angular Velocity (%s - Trial %d)', m, trial));
    xlabel('Time (s)'); ylabel('Velocity (rad/s)'); grid on;
    
    % บันทึกไฟล์ Position และ Velocity (.fig, .png, .pdf)
    saveFigureFiles(f1, fullfile(savePath, 'Position'));
    saveFigureFiles(f2, fullfile(savePath, 'Angular_Velocity'));
    close([f1, f2]);
end

% 3. กราฟ Phase Relationship ( Phase A และ Phase B )
if isfield(out, 'out_PhaseA') && isfield(out, 'out_PhaseB')
    f_phase = figure('Name', 'Phase_Relationship', 'Visible', 'off');
    plot(out.out_PhaseA.Time, out.out_PhaseA.Data + 1.5, 'b', 'LineWidth', 1.2); hold on;
    plot(out.out_PhaseB.Time, out.out_PhaseB.Data, 'r', 'LineWidth', 1.2);
    ylim([-0.5 3]);
    title(sprintf('Phase Relationship Channel A & B (Trial %d)', trial));
    xlabel('Time (s)'); ylabel('Logic Level');
    legend('Phase A (+1.5 Offset)', 'Phase B'); grid on;
    
    phasePath = fullfile(trialFolder, 'Phase_Relationship');
    saveFigureFiles(f_phase, phasePath);
    close(f_phase);
end

fprintf('บันทึกข้อมูลและกราฟ Trial %d เรียบร้อยแล้ว!\n', trial);

% --- Local Function สำหรับบันทึกไฟล์ 3 นามสกุล ---
function saveFigureFiles(figHandle, basePath)
    saveas(figHandle, [basePath '.fig']);
    saveas(figHandle, [basePath '.png']);
    exportgraphics(figHandle, [basePath '.pdf'], 'ContentType', 'vector');
end